<!doctype html>
<html>
<head>
    <title>Edit Data</title>
</head>
<body>
    <h1>Edit Data</h1>
    <?php
      require_once dirname(__FILE__,2)."/Model/modelHandler.php";
        if (isset($msg)) {
            //echo $msg . "<br>";
        }

        // ambil data dari database
        $id = isset($_GET['id']) ? $_GET['id'] : "";
                
        $previewData = new dataHandler();
        list($checkData,$data) = $previewData->readOneDataById($id);
  print_r($data);
    ?>
    <form action="edit.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <label for="name">Nama:</label><br>
        <input type="text" name="name" id="name" value="<?php echo $data['name']; ?>"><br>
        <label for="price">Harga:</label><br>
        <input type="text" name="price" id="price" value="<?php echo $data['price']; ?>"><br>
        <label for="description">Deskripsi:</label><br>
        <textarea name="description" id="description"><?php echo $data['description']; ?></textarea><br>
        <input type="submit" name="update" value="Update">
    </form> 
</body>
</html>