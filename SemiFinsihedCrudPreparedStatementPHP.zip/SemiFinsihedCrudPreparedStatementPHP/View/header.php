
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../Fomantic%2520UI/dist/semantic.min.css">
    <script src="../Fomantic%2520UI/dist/script.min.js"></script>
    <script src="../Fomantic%2520UI/dist/jquery.min.js"></script>
    <title>Document</title>
</head>
