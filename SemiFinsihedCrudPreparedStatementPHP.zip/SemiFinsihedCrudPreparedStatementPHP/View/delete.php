
<!doctype html>
<html>
<head>
    <title>Hapus Data</title>
</head>
<body>
    <h1>Hapus Data</h1>
    <?php
        if (isset($msg)) {
            echo $msg . "<br>";
        }

        // ambil data dari database
        $id = isset($_GET['id']) ? $_GET['id'] : "";
        $data = $model->readOne($id);
    ?>
    <form action="delete.php" method="post">
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <p>Apakah Anda yakin ingin menghapus data ini?</p>
        <table>
            <tr>
                <th>ID</th>
                <td><?php echo $data['id']; ?></td>
            </tr>
            <tr>
                <th>Nama</th>
                <td><?php echo $data['name']; ?></td>
            </tr>
            <tr>
                <th>Harga</th>
                <td><?php echo $data['price']; ?></td>
            </tr>
            <tr>
                <th>Deskripsi</th>
                <td><?php echo $data['description']; ?></td>
            </tr>
            <tr>
                <th>Dibuat</th>
                <td><?php echo $data['created']; ?></td>
            </tr>
        </table>
        <br>
        <input type="submit" name="delete" value="Hapus">
        <a href="index.php">Batal</a>
    </form> 
</body>
</html>