<!doctype html>
<html>

<head>
	<title>Tampilan Data</title>
	<link rel="stylesheet" href="../Fomantic%20UI/dist/semantic.min.css">

	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/buttons.semanticui.min.css">
	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/dataTables.semanticui.min.css">
	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/css/responsive.semanticui.min.css">


	<script src="../Fomantic%20UI/dist/jquery.min.js"></script>
	<script src="../Fomantic%20UI/dist/semantic.min.js"></script>
	<!-- only one file needed to show the datatable -->
	<script src="../Fomantic%20UI/dist/dataTables/datatables.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/dataTables.responsive.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/dataTables.semanticui.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/responsive.semanticui.min.js"></script>
	<!-- container to show pdf, csv,excel,copy buttons -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.html5.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/pdfmake.min.js"></script>
	<!-- vfs_fonts.js to make pdf worked, and it has to be under pdfmake.min.js -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/vfs_fonts.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/jszip.min.js"></script>
	<!-- colVis = Column visibility to remove / choose specific row -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.colVis.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.print.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/responsive.semanticui.min.js"></script>

</head>

<body>
	<h1>Tampilan Data</h1>
	<?php
        require_once dirname(__FILE__,2)."/Model/modelHandler.php";
        $previewData = new dataHandler();
        $data = $previewData->readAll();

    ?>
	<div class="ui container">
		<table id="dataItem" class="ui table">
		<thead>
			<tr>
				<th>ID</th>
				<th>Nama</th>
				<th>Harga</th>
				<th>Deskripsi</th>
				<th>Dibuat</th>
				<th>Aksi</th>
			</tr>
			</thead>
			<tbody>
			<?php
            if (count(array($data)) > 0) {
                foreach($data as $item){
                    echo "<tr>";
                    echo "<td>" . $item['id'] . "</td>";
                    echo "<td>" . htmlspecialchars($item['name']) . "</td>";
                    echo "<td>" . $item['price'] . "</td>";
                    echo "<td>" . $item['description'] . "</td>";
                    echo "<td>" . $item['creation_date'] . "</td>";
									// datatable doesnt support colspan , so it has to be in the same column action
                    echo "<td><a href='edit.php?id=" . $item['id'] . "'>Edit</a><a href='delete.php?id=" . $item['id'] . "'>Delete</a></td>";
                    echo "</tr>";
                }


            } else {
                echo "<tr><td colspan='7'>Tidak ada data</td></tr>";
            }

        ?>
        </tbody>
		</table>
	</div>
	<br>
	<a href="add.php">Tambah Data</a>
	<script>
		// there is no offcial doc at 2023 found that user is able to remove kol actions whenever one of the buttons datatable is clicked
		$(function() {
			$("#dataItem").DataTable({
				dom: "<'ui grid'" +
					"<'row'" +
					"<'four wide column'l>" +
					"<'center aligned eight wide column'B>" +
					"<'right aligned four wide column'f>" +
					">" +
					"<'row dt-table'" +
					"<'sixteen wide column'tr>" +
					">" +
					"<'row'" +
					"<'seven wide column'i>" +
					"<'right aligned nine wide column'p>" +
					">" +
					">",
				buttons: [
					'copy', 'csv', 'excel', 'pdf', 'print', 'colvis'
				],
				lengthMenu: [
					[5, 10, 25, 50, -1],
					[5, 10, 25, 50, "All"]
				],
				pagingType: 'full_numbers',
				pageLength: 5,
				language: {
					search: "Cari : ",
					paginate: {
						first: "Awal",
						last: "Akhir",
						previous: "<i class='arrow left icon'></i>",
						next: "<i class='arrow right icon'></i>"
					},
					info: " _START_ to _END_ of _TOTAL_ ",
					infoEmpty: "No data found",
					infoFiltered: "(disaring dari _MAX_ entri keseluruhan)",
					lengthChange: false,
				},
			})
		})

	</script>
</body>

</html>
