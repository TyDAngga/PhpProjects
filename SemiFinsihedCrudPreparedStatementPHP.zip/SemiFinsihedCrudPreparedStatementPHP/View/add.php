<!doctype html>
<html>
<head>
    <title>Tambah Data</title>
</head>
<body>
    <h1>Tambah Data</h1>

  

    <?php
      $folderAppPath = dirname($_SERVER['PHP_SELF'],2);
      $filePathRequestHandler = "http://". $_SERVER["SERVER_NAME"].$folderAppPath."/Controller/controllerManager.php"; 
      $strEncoded = urlencode("<script> alert(21) </script>");
      echo $str;
        if (isset($_GET['data'])) {
          // prevent XSS attack in url. filter malicious code to string
           $data = filter_var($_GET['data'], FILTER_SANITIZE_STRING);
             echo $_GET['data'] . "<br>";
           // echo "<script> history.replaceState({}, '', '$folderAppPath/View/add.php'); </script>";
        }
    
    ?>
<script> history.replaceState({}, '', '');

  </script>
    <form action="<?php echo $filePathRequestHandler;?>" method="post">
        <label for="name">Nama:</label><br>
        <input type="text" name="name" id="name"><br>
        <label for="price">Harga:</label><br>
        <input type="text" name="price" id="price"><br>
        <label for="description">Deskripsi:</label><br>
        <textarea name="description" id="description"></textarea><br>
        <input type="submit" name="submit" value="Tambah">
    </form> 
</body>
</html>