<?php

class DBConnector {

   protected $errCustom = 
          "<div style='
                background:#333;
                position:relative;
                margin: 0 auto;
                padding:10px;
                border-radius: 10px;
                width:max-content;
                '> 
                <p style=
                'background:black;
                text-align:center;
                border-radius:10px;
                color:cyan; padding:10px;
                width:max-width'>- Gagal terhubung ke database - <p>";

    
    function connectionDB(){

      @$conn = mysqli_connect("localhost", "root", "", "insertShowAi");

      if(!$conn){
       echo (error_get_last()["message"]);
      }
      return $conn;

}

}





?>
