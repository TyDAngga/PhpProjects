<?php 

/*

singeleton class adalah class yang berjumlah x1 didalam file dan menyedikana mekanisme global untuk mengakses object construct

something to remember :
1. koneksi db seperti  new mysqli( ) / mysqli_connect()  tidak bisa dipakai jika ditempatkan function __construct() saat instansiasi kelas
contoh :
$conn = new classConn();
$queryResult = $conn->query($sqlQuery) / mysqli_connect($sqlQuery,$conn) 
-- dalam contoh diatas $conn tidak bisa dipakai karena merupakan objek instansiasi class

*/
class DBConnection
{
    // Hold the class instance.
    private static $instance = null;
    private $conn;
 
    private $host = 'localhost';
    private $user = 'root';
    private $pass = '';
    private $name = 'insertshowai';

 
    // The private constructor to prevent direct creation of object.
    function __construct()
    {
        $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->name);
 
        if (mysqli_connect_error()) {
            die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
        }
    }
 
    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new DBConnection();
           return self::$instance;
        }
 
        
    }
 
    public function getConnection()
    {
        return $this->conn;
    }
}

/*
$conDB = new DBConnection();
$DBconnector = $conDB->getConnection();

// Usage
$instance = DBConnection::getInstance();
$conn = $instance->getConnection();


$queryShowAll = "SELECT * FROM tbl_products" ;

$result = $DBconnector->query($queryShowAll);

while($row = mysqli_fetch_assoc($result)){
echo $row['name'];
echo $row['price'];
echo $row['description'];
};
*/
?>