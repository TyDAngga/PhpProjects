<?php

class Autoloader{
  public static function fileLoader($namepace){
    $className = str_replace("\\","/",$namepace);
    $filename = dirname(__FILE__."/$className",2);
    if(file_exists($filename)){
      require_once $filename;
    }
  }
}

spl_autoload_register(["Autoloader","fileLoader"]);

?>