<?php
require_once(dirname(__FILE__,2)."/Model/modelHandler.php");
class dataController
{
    private $model;

    public function __construct()
    {
        // memanggil class model
        $this->model = new dataHandler();
    }

    public function index()
    {
        // memanggil fungsi read() pada class model
        $result = $this->model->read();

        // menampilkan data hasil pemanggilan fungsi read()
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            echo "ID: {$id}<br>";
            echo "Nama: {$name}<br>";
            echo "Harga: {$price}<br>";
            echo "Deskripsi: {$description}<br>";
            echo "Tanggal Dibuat: {$created}<br>";
        }
    }

    public function readOne($id)
    {
        // mengisi nilai id pada class model
        $this->model->id = $id;

        // memanggil fungsi readOne() pada class model
        $this->model->readOne();

        // menampilkan data hasil pemanggilan fungsi readOne()
        echo "ID: {$this->model->id}<br>";
        echo "Nama: {$this->model->name}<br>";
        echo "Harga: {$this->model->price}<br>";
        echo "Deskripsi: {$this->model->description}<br>";
        echo "Tanggal Dibuat: {$this->model->created}<br>";
    }

    public function create($name, $price, $description)
    {
        // mengisi nilai kolom pada class model
        $this->name = $name;
        $this->price = $price;
        $this->description = $description;
        $this->created = date('Y-m-d H:i:s');

        // memanggil fungsi create() pada class model
        if ($this->model->create()) {
            echo "Data berhasil ditambahkan";
        } else {
            echo "Terjadi kesalahan saat menambahkan data";
        }
    }

    public function update($id, $name, $price, $description)
    {
        // mengisi nilai kolom pada class model
        $this->model->id = $id;
        $this->model->name = $name;
        $this->model->price = $price;
        $this->model->description = $description;

     if ($this->model->update()) {
            echo "Data berhasil diupdate";
        } else {
            echo "Terjadi kesalahan saat mengupdate data";
        }
    }

    public function delete($id)
    {
        // mengisi nilai id pada class model
        $this->model->id = $id;

        // memanggil fungsi delete() pada class model
        if ($this->model->delete()) {
            echo "Data berhasil dihapus";
        } else {
            echo "Terjadi kesalahan saat menghapus data";
        }
    }
}
$controller = new dataController();
$controller->create("Produk A", 100000, "Produk A adalah produk terbaik");
?>