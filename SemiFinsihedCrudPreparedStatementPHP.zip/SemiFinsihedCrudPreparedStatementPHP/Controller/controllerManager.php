

<?php

require_once dirname(__FILE__,2)."/Model/modelHandler.php";



class requestHandler
{
    // model
    private $model;

    // constructor
    function __construct()
    {
        $this->model = new dataHandler();
        $this->folderPathView = dirname($_SERVER["PHP_SELF"],2)."/View"; 

    }

    // handle request
    public function handleRequest()
    {
        if (isset($_POST['submit'])) {
            // ambil data dari form
            $name = isset($_POST['name']) ? $_POST['name'] : "";
            $price = isset($_POST['price']) ? $_POST['price'] : "";
            $description = isset($_POST['description']) ? $_POST['description'] : "";
            // tambahkan data
            if ($this->model->create($name, $price, $description)) {
                $msg = "Successfully Added";
                header("location:$this->folderPathView/add.php?data=$msg");
            } else {
                $msg = "Terjadi kesalahan, data tidak ditambahkan!";
                header("location:$this->folderPathView/add.php?data=$msg");
            }
          
        } else if (isset($_POST['update'])) {
            // ambil data dari form
            $name = isset($_POST['name']) ? $_POST['name'] : "";
            $price = isset($_POST['price']) ? $_POST['price'] : "";
            $description = isset($_POST['description']) ? $_POST['description'] : "";
            $id = isset($_POST['id']) ? $_POST['id'] : "";

            // update data
            if ($this->model->update($name, $price, $description, $id)) {
                $msg = "Data telah diupdate!";
            } else {
                $msg = "Terjadi kesalahan, data tidak diupdate!";
            }
        } else if (isset($_POST['delete'])) {
            // ambil data dari form
            $id = isset($_POST['id']) ? $_POST['id'] : "";

            // hapus data
            if ($this->model->delete($id)) {
                $msg = "Data telah dihapus!";
            } else {
                $msg = "Terjadi kesalahan, data tidak dihapus!";
            }
        }else{
          header("Location:$this->folderPathView/view.php");
        }


    }
}

$requestHandler = new requestHandler();
$requestHandler->handleRequest();
?>