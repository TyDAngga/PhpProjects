<?php



require_once dirname(__FILE__,2)."/Connection/dbConfig.php";

/* gettin root (main) folder of the project
echo basename(dirname(__DIR__));
*/

class dataHandler
{

    // nama tabel
    private $table_name = "tbl_products";
    private $id;
    // nama kolom yg terisi manual
    private $name = "name";
    private $price = "price";
    private $description = "description";

    // constructor dengan $db sebagai koneksi database
    function __construct()
    {
       $instance = new DBConnector();
       $this->conn = $instance->connectionDB();

    }

    // fungsi untuk membaca semua data
    function readAll()
    {
      
        $query = "SELECT
                    *
                FROM
                    " . $this->table_name . " 
                ORDER BY
                    name ASC";

        // prepare query statement
        $stmt = $this->conn->prepare($query);
        if(!$stmt){
          echo "failed to execute data. ". $this->conn->error;
        }
        else{
          if(!$stmt->execute()){
            echo "failed to show all data. ". $this->conn->error;
          }
          else{
            $stmt->execute();
            $getResult = $stmt->get_result();
            // alternative way mysqli_stmt_get_result();

            return $getResult;
          }
          
        }
        
    }



    // fungsi untuk menambahkan data
    function create($name="", $price="",$description="")
    {
        if($name === "" || $price === ""){
            return null;
        }else{
            $stmt = $this->conn->prepare("INSERT INTO tbl_products (name, price, description) VALUES (?,?,?)");

          if (!$stmt) {
            echo "Error: " . $this->conn->error;
          } else {
            $name = htmlspecialchars(strip_tags($name));
            $price = htmlspecialchars(strip_tags($price));
            $description = htmlspecialchars(strip_tags($description));
            $stmt->bind_param("sds", $name, $price, $description);
            $stmt->execute();
            return true;
          }
        }

  }
  
      function readOneDataById($id="")
    {

       if($id === ""){
         echo "id cant be empty";
         return null;
       }
       
       else{
          $query = "SELECT
                   *
                FROM
                    " . $this->table_name . " 
                WHERE
                    id = ?
                LIMIT
                    0,1";

        $stmt = $this->conn->prepare($query);
        if(!$stmt){
          echo $this->conn->error;
        }else{
          $stmt->bind_param("i",$id);
          $stmt->execute();
          $getResult = $stmt->get_result();
					// parenthesis () required since tht is an array result lol
          $result = $getResult->fetch_assoc();
          $checkResult = $getResult->num_rows;
          if(!$getResult){
            return null;
          }
          else{
           return [$checkResult,$result];
          }
          
        }
       }

    }

  function update($id="",$name="",$price="",$description="")
{

    
     if($id === "" || $name === "" || $price === "" || $description === ""){
       return null;
     }

     else{
			 /* list used to assign variabel from returned array; 
			 u can do this instead = $checkResult = self::readOneDataById($id)[0];
			 */
       list($checkResult) = self::readOneDataById($id);
       /*
			 if statement can evaluate the $checkResult whether tht is empty, / return null as unaccepted value , so u can also do this instead :
			 if the value it just return 1 array mysqli_fetch_assoc :
			 this code below will only be executed if the variable has value, if that just empty string /nullit wont be executed;
			 if($resultArray){// do something} or u can use ternary operator instead, 
			 using if statment if the code doesnt exist = if(!resultArray){ echo "data doesnt exist"; return null;}
			 */
			 if($checkResult < 1){
           echo "Data id doesnt exist.! <br> ";
           return null;
        }
       $query = "UPDATE
         " . $this->table_name . "
         SET
             name = ?,
             price = ?,
             description = ?
         WHERE
             id = ?";

    // prepare query statement
       $stmt = $this->conn->prepare($query);
       if(!$stmt){
         echo "something wrong with the query <br>";
         return null;
       }else{
          $id =  htmlspecialchars(strip_tags($id));
          $name = htmlspecialchars(strip_tags($name));
          $price = htmlspecialchars(strip_tags($price));
          $description = htmlspecialchars(strip_tags($description));
         
          $stmt->bind_param("sdsi",$name, $price, $description,$id);
          $stmt->execute();
          return true;
       }
        

     }
      

 

}

  
function delete($id = "")
{ 
   
    if($id === ""){
      return null;
    }else{
      list($checkData) =  self::readOneDataById($id);
       echo $checkData;
      if($checkData < 1){
        return null;
      }else{
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $id = htmlspecialchars(strip_tags($id));
        $stmt->bind_param("i",$id);
        $stmt->execute();
        if (!$stmt->execute()) {
            return null;
        }else{
          return true;
        }

        
        }
      }
  
 
  }

  
}


/*
usage : 
$obj = new dataHandler();
$insertData = $obj->create();
$updateData = $obj->update("1");
if($insertDat === true){
	echo "data has been insert";
}
*/