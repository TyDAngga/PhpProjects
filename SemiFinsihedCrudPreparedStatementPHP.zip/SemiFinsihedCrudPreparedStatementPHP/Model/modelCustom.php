<?php
namespace Model;

require_once dirname(__FILE__,2)."/Connection/dbConfig.php";

use Connection\DBConnector;

class modelCustomCrud{
      private $table_name = "tbl_products";
    private $conDB;
    // nama kolom
    private $id;
    private $name;
    private $price;
    private $description;
    private $created; //datetime datatype,  use now() as a query value to insert currentdate-time;
    private $modified;
  
  function __construct(){
    $this->conDB = new DBConnector();
  }
  
  function selectAll(){
    $connDB = new mysqli("localhost","root","","insertshowai");
    $queryStmt = "SELECT * from $this->table_name";
    $resultData = mysqli_query($connDB,$this->conDB);
    print_r(mysqli_fetch_array($resultData));
  }
  
}

$showData = new modelCustomCrud();
$showData->selectAll();