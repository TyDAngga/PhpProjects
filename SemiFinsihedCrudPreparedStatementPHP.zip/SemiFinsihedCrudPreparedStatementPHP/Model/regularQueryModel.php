<?php

require_once dirname(__FILE__,2)."/Connection/dbConfig.php";

class manageSystem {
	    private $table_name = "tbl_products";
	function __construct(){
		$instanceConn = new DBConnector();
		$this->conn = $instanceConn->connectionDB();
	}
		function insertData($name=" ", $price=" ", $description=" "){ 
		
		$query = "INSERT INTO $this->table_name (name,price,description) values ('$name','$price','$description')";
		if(!$this->conn->query($query)){
				echo @mysqli_error();
				echo("Mysqli query is incorrect <br>");
		}else{
			return true;
		}
		
		
	}
	
	function readOneItem($id=""){
		if($id === ""){
			echo "id cannot be empty";
		}else{
			$queryReadOne = "Select * from " . $this->table_name  ."  where id=$id";
			$resultData = $this->conn->query($queryReadOne);
			if(!$resultData){
				echo "something when wrong with the  sql syntax";
			}else{
				$dataResult = $resultData->fetch_assoc();
				$checkData = $resultData->num_rows;
				return [$checkData,$dataResult];
			}
		}
	}
	
	function updateData($id="",$name="",$price="",$description=""){
		if($id !== "" || $name !== "" || $description !==""){
				list($checkId) = $this->readOneItem($id);
				if($checkId < 1){
					echo "id not found";
					
				}else{
					$queryUpdate = "UPDATE $this->table_name SET name='$name', price='$price', description='$description' where id='$id'";
					if(!$this->conn->query($queryUpdate)){
						echo "Something went wrong with the sql query";
					}else{
						return true;
					}
				}
		}else{
			return null;
		}
	}
	
	function deleteData($id=""){
		list($id) = $this->readOneItem($id);
		if($id < 1){
            return 404;
		}else{
			$query = "DELETE FROM $this->table_name where id='$id'";
			if(!$this->conn->query($query)){
				echo "Something went wrong with query sql";
			}else{
				return true;
			}
		}
	}
}


/*
usage : 
$app = new manageSystem();
if u put number and char in a string , it will still valid, the sql query php syntax will take the first number , and therow the chars behind it, if u are not using prepared statment and insert symbol (') it can causes sql error. e.g. = $app->updateItem("2vav"); it will update the item at rwo 2
usage :
if($app->readOneItem("12")){
	
	print_r($app->readOneItem("3's3casx")[1]);
}

// better dont call the method in condition if, kus everytime the method return any value it will be admitted as true; and dont use http_response_code() as indicator message kus it will affect the behavior of the browser lol.
$result = $app->deleteData(2);
if($result === true){
    echo "data has been deleted";
}else if ($result == 404){
    echo "data id not found";
}else{
    echo "Failed to delete item";
}
*/
?>
