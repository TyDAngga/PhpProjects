if statment vs ternary operator in evaluating mysqli_query :


<?php

class manageSystem{
	function __construct(){
		$this->conn = $this->connectionDB();
		$this->tableName = "tbl_products";
	}
	function connectionDB(){
		$conn = mysqli_connect("localhost","root","","insertshowai");
		if(!$conn){
			echo $conn->connect_errno;
			die("Something went wrong with database connection");
		}
		else{
			return $conn;
		}
	}
	
	function insertItem($name ="", $price= "", $description=""){
		$query = "INSERT INTO $this->tableName (name,price,description) values('$name','$price','$description')";
		!$this->conn->query($query) ? print "failed" : print  "success";

			// if using echo to indicate message success of query && the if statement / ternary opt contain condition that called this method class which using echo message again, it will be thrown to else conditon and echo message in else statement will be printed out instead lol; so it will always be good thing to put true /null / false to indicate as a message; 
		
			// conclusion ternary opt cannot return value; so it has to has value by using print;
		/*
		if(!$this->conn->query($query)){	
			return null;
		}else{
			return true;
		}
		*/

	}
}

$manageSystem = new manageSystem();


if($manageSystem->insertItem("Handphone","1,500,000","Latest stable Laptop")){
	header("location:".$_SERVER['SCRIPT_FILENAME']."?ab=cx");
}
	



?>
