<?php



class errIdentifier {
  function customErr(){
    $cssFile = "<link rel='stylesheet' href=\" ../../fomanticUI/dist/semantic.css \">";
    echo $cssFile;
    echo "<p class=\"ui message container \"> welcome </p>";
    
    date_default_timezone_set("Asia/Jakarta");
    $this->errMessage = error_get_last()['message'];
    $this->errLine = error_get_last()['line'];
    $this->errFile = error_get_last()['file'];
    $this->dateTime = date('l, d F Y, H:i:s');
    $this->errTableMode = "
    <tr id='rowTableErr'>
    <td>$this->errMessage </td>
    <td>$this->errLine </td>
    <td>$this->errFile </td>
    <td>$this->dateTime</td>
    <td>
      <div class='ui fitted checkbox slider'>
          <input type=\"checkbox\" name='' id='chkBoxLogErr'>
          <label></label> 
      </div>
    </td>
    </tr>
    ";
    
     error_log($this->errTableMode,3,dirname(__FILE__)."/logError.html") ? print "" : print "failed to record error";
  }
  
  function displayCustomErr(){
    echo "<div class=\"ui container custom-width-m negative center aligned  message\" > err </div>";
  }
}


$errClass = new errIdentifier();
// better dont use new mysqli() karena jika menggunakan tanda !$conDb di if else maka itu tidak berpengaruh jika koneksinya error.
$conDB = mysqli_connect("localhost","root","as","insertShowAi");

if(!$conDB){
  $errClass->customErr();
  $errClass->displayCustomErr();
}


?>

