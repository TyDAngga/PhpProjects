<?php
class errTracker{
  function localErrorTracer(){
    header("refresh:1");
    $conDB = mysqli_connect("localhost","root","","insertShowAi");
    date_default_timezone_set("Asia/Jakarta");
    $errMessage = error_get_last()['message'];
    $errLine = error_get_last()['line'];
    $errFile = error_get_last()['file'];
    $dateTime = date('l, d F Y, H:i:s');
    $chkBoxHtml = "
        <div class='ui fitted checkbox slider'>
          <input type='checkbox' name='' id='chkBoxLogErr'>
          <label></label> 
        </div>";
    $fileName = 'errors.json';
    $errJSONFile = json_decode(file_get_contents($fileName));
    $arryErrMessage = [$errMessage,$errLine,$errFile,$dateTime,$chkBoxHtml];
    if($errJSONFile == null){
        $errJSON = array(
        "data"=>array(
          $arryErrMessage
          )
        );
    }
    else{
        $stdObjk = new stdClass();
        $errJSON = (array)$errJSONFile;
        array_push($errJSON["data"],$arryErrMessage);
        //print_r($errJSON);
    }
      $errArrayEncode = json_encode($errJSON);
    print_r($errArrayEncode);
      file_put_contents($fileName,$errArrayEncode) ? "" : print "failed to record the error" ;
  }
}





$errTracer = new errTracker();

//$errTracer->localErrorTracer();





/*

$errJSON_Array = (array)$errJSONFile;

$newElement = [$errMessage,$errLine,$errFile,$dateTime];
array_push($errJSON_Array['data'], $newElement);

print_r($errJSON_Array);

print_r($errArryJson);

*/










?>