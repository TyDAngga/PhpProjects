<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="../Fomantic%20UI/dist/semantic.min.css">
	<!-- two of these files used to allign the filter show entries precisly-->
	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/buttons.semanticui.min.css">
	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/dataTables.semanticui.min.css">
	<link rel="stylesheet" href="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/css/responsive.semanticui.min.css">


	<script src="../Fomantic%20UI/dist/jquery.min.js"></script>
	<script src="../Fomantic%20UI/dist/semantic.min.js"></script>
	<!-- only one file needed to show the datatable -->
	<script src="../Fomantic%20UI/dist/dataTables/datatables.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/dataTables.responsive.min.js"></script>
	<!--  two of these files are optional for responsiveness -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/dataTables.semanticui.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/responsive.semanticui.min.js"></script>
	<!-- container to show pdf, csv,excel,copy buttons -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.html5.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/pdfmake.min.js"></script>
	<!-- vfs_fonts.js to make pdf worked, and it has to be under pdfmake.min.js -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/vfs_fonts.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/jszip.min.js"></script>
	<!-- colVis = Column visibility to remove / choose specific row -->
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.colVis.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Buttons-2.3.6/js/buttons.print.min.js"></script>
	<script src="../Fomantic%20UI/dist/dataTables/Xtensions/Responsive-2.4.1/js/responsive.semanticui.min.js"></script>

<style>
	
	/* re-design pagination when reach tablet or smaller screen size from vertical to horizontal mode;*/
	#tableErr_paginate{
		/* to make sure the parent keep shrinking if the size of web page is smaller*/
		display: flex; 
	}
	#tableErr_paginate *{
		display: inline-block;
		width: max-content !important;
		
	}
	</style>
</head>

<body>


	<div class="ui container" style="display:grid; top:4rem; position:relative;">

		<div class="ui container custom-width-m negative center hidden aligned message">
			<i class="close icon"></i>
			<div class="header">
				<i class="attention yellow padding-10 icon"></i>
				<span></span>
			</div>

		</div>



		<div class="ui container">
			<table id="tableErr" class="ui unstackable center aligned celled striped table">
				<thead>
					<tr>

						<th>Error Name</th>
						<th>Error Line</th>
						<th>Error File</th>
						<th>Date Time Occured</th>

					</tr>
				</thead>

			</table>
		</div>
	</div>
	<script>
		$(function() {

			var table = $('#tableErr').DataTable({
				dom: "<'ui grid'" +
					"<'row'" +
					"<'four wide column'l>" +
					"<'center aligned eight wide column'B>" +
					"<'right aligned four wide column'f>" +
					">" +
					"<'row dt-table'" +
					"<'sixteen wide column'tr>" +
					">" +
					"<'row'" +
					"<'seven wide column'i>" +
					"<'right aligned nine wide column'p>" +
					">" +
					">",
				buttons: [
					'copy', 'csv', 'excel', 'pdf', 'print', 'colvis'
				],
				lengthMenu: [
					[5, 10, 25, 50, -1],
					[5, 10, 25, 50, "All"]
				],
				pagingType: 'full_numbers',
				pageLength: 5,
				language: {
					search: "Cari : ",
					paginate: {
						first: "Awal",
						last: "Akhir",
						previous: "<i class='arrow left icon'></i>",
						next: "<i class='arrow right icon'></i>"
					},
					info: " _START_ to _END_ of _TOTAL_ ",
					infoEmpty: "No data found",
					infoFiltered: "(disaring dari _MAX_ entri keseluruhan)",
					lengthChange: false,
				},
				"ajax": {
					"url": "dataUser.json",
					"dataSrc": ""
				},
				"columns": [{
						"data": "id"
					},
					{
						"data": "name"
					},
					{
						"data": "age"
					},
					{
						"data": "address"
					}
				],
				 // autoWidth has to be false remove the default to make responsive work. 
        "autoWidth": false,
				/*
				        scrollY: 200,
        scrollX: true,
					*/
			})
			/* demonstrate how to change styling of buttons
			$('.ui.button', table.buttons().container())
				.addClass('basic primary')
				*/
		})

	</script>
</body>

</html>
